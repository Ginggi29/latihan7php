
<!DOCTYPE html>
<html>
<head>
	<title>Belajar POST</title>
</head>
<body>

<form action="bagian4.php" method="POST">
	Masukan Nama :
	<input type="text" name="nama">
	<br>
	<button type="submit" name="submit">Kirim!</button> 
</form>	

</body>
</html>
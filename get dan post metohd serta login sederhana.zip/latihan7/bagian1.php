<?php $pmr =[
	[
		"nama" => "Robert Downey Jr", 
		"sebagai" => "Tony Stark",
		"superhero" => "Iron Man", 
		"negara" => "Amerika Serikat",
		"gambar" => "robert.jpg"
	],
	[
		"nama" => "Chris Evans", 
		"sebagai" => "Stive Roger",
		"superhero" => "Captain America", 
		"negara" => "Amerika Serikat",
		"gambar" => "chris.jpg"
	],
	[
		"nama" => "Chris Hemsworth", 
		"sebagai" => "Thor Odinson",
		"superhero" => "Thor", 
		"negara" => "Australia",
		"gambar" => "hemsworth.jpg"
		],
	[
		"nama" => "Scarlett Johannson", 
		"sebagai" => "Natasha Romanoff",
		"superhero" => "Black Widow", 
		"negara" => "Amerika Serikat",
		"gambar" => "scarlett.jpg"
	],
	[
		"nama" => "Brie Larson", 
		"sebagai" => "Carol Danvers",
		"superhero" => "Captain Marvel", 
		"negara" => "Amerika Serikat",
		"gambar" => "brie.jpg"
	],
];
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>LATIHAN GET</title>
</head>
<body>
<h1>DAFTAR PEMERAN AVANGER END GAME</h1>
	
	<ul>
	<?php foreach ($pmr as $avg) : ?>
		<li>
			<a href="bagian2.php?nama=<?= $avg["nama"]; ?>&sebagai=<?= $avg["sebagai"]; ?>&superhero=<?= $avg["superhero"]; ?>&negara=<?= $avg["negara"]; ?>&gambar=<?= $avg["gambar"]; ?>"><?= $avg["nama"]; ?></a>
		</li>
	<?php endforeach; ?>
	</ul>

</body>
</html>


<!DOCTYPE html>
<html>
<head>
	<title>POST</title>
</head>
<body>
	<h1>Selamat Datang, <?= $_POST["nama"];  ?></h1>


</body>
</html>
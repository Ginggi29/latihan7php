<!DOCTYPE html>
<html>
<head>
	<title>Halaman Admin</title>
</head>
<body>
	
	<h1>SELAMAT DATANG ADMIN</h1>


	<a href="login.php">Logout</a>

</body>
</html>
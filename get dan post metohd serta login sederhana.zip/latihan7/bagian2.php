<?php 

if ( !isset($_GET["nama"]) || 
	!isset($_GET["sebagai"]) || 
	!isset($_GET["superhero"]) || 
	!isset($_GET["negara"]) || 
	!isset($_GET["gambar"])) {
	
	header("Location:bagian1.php");
	exit;
}

 ?>


<!DOCTYPE html>
<html>
<head>
	<title>Detail Pemeran Avanger Endgame</title>
</head>
<body>

	<ul>
		<li><img src="img/<?= $_GET["gambar"]; ?>"></li>
		<li><?= $_GET["nama"]; ?></li>
		<li><?= $_GET["sebagai"]; ?></li>
		<li><?= $_GET["superhero"]; ?></li>
		<li><?= $_GET["negara"]; ?></li>
	</ul>

<a href="bagian1.php">Kembali ke Daftar Pemeran Avanger Endgame</a>


</body>
</html>